//
//  FLEXSystemLogTableViewController.h
//  UICatalog
//
//  Created by Ryan Olson on 1/19/15.
//  Copyright (c) 2015 f. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FLEXSystemLogTableViewController : UITableViewController

@end
